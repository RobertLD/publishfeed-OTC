
TWEET_MAX_LENGTH = 140
TWEET_URL_LENGTH = 22
TWEET_IMG_LENGTH = 0 #23

DB_TEST_URL = 'sqlite://' # in memory
#DB_TEST_URL = 'sqlite:///test.db' # file 
